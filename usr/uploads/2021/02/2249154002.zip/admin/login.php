<?php include 'common.php'; if ($user->hasLogin()) { $response->redirect($options->adminUrl); } $rememberName = htmlspecialchars(Typecho_Cookie::get('__typecho_remember_name')); Typecho_Cookie::delete('__typecho_remember_name'); $bodyClass = 'body-100'; include 'header.php'; ?>
  
  <head>
    <link href="/admin/css/loginstyle.css" rel="stylesheet" type="text/css" media="all" /></head>
  
  <body>
    <div class="main-w3layouts wrapper">
      <div class="main-agileinfo">
        <div class="agileits-top">
          <form action="<?php $options->loginAction(); ?>" method="post" name="login" role="form">
            <label for="name" class="sr-only">
              <?php _e( '用户名'); ?></label>
            <input type="text" id="name" name="name" value="<?php echo $rememberName; ?>" placeholder="<?php _e('用户名'); ?>" class="text-l w-100" autofocus />
            <label for="password" class="sr-only">
              <?php _e( '密码'); ?></label>
            <input type="password" id="password" name="password" class="text-l w-100" placeholder=" <?php _e('密码'); ?>" />
            <div class="wthree-text">
              <ul>
                <li>
                  <label for="remember">
                    <input type="checkbox" name="remember" class="checkbox" value="1" id="remember" />
                    <?php _e( '下次自动登录'); ?></label>
                </li>
              </ul>
              <div class="clear"></div>
            </div>
            <input type="submit" value="登录">
            <ul>
              <p class="more-link">
                <a href="<?php $options->siteUrl(); ?>">
                  <?php _e( '返回首页'); ?></a>&bull;
            	<!--<a href="https://blog.racns.com/index.php/multi_oauthlogin.html?page=qqlogin">
                  	<img src="http://me.tongleer.com/mob/resource/images/qq_login_blue.png" />
          		</a>-->
                <a href="<?php $options->adminUrl('register.php'); ?>">
                  <?php _e( '用户注册'); ?></a>
              </p>
            </ul>
          </form>
        </div>
      </div>
  </body>
  
  </html>
  <?php include 'common-js.php'; ?>
    <script>$(document).ready(function() {
        $('#name').focus();
      });</script>
    <?php include 'footer.php'; ?>